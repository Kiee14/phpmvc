<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial- scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Halaman <?= $data['judul']; ?></title>
    <link rel="stylesheet" href="http://localhost/phpmvc/public/css/bootstrap.css">
</head>
<body>
    <!-- <div class="container mt-5">
        <div class="card" style="max-width: 540px;">
            <div class="row no-gutters">
                <div class="col-md-4">
                    <img src="img/gambar2.jpg" class="card-img" alt="...">
                </div> -->
                <div class="col-md-8">
                    <div class="card-body">
                        <h5 class="card-title">DAFTAR GURU KOMPETENSI KEAHLIAN RPL</h5>
                        <p class="card-text"></p>
                        <table class="table table-bordered" id="myTable">
                            <thead>
                                <tr>
                                    <th scope="col">Nama Guru</th>
                                    <th scope="col">Kompetensi Keahlian</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>IVANS ZUWANTA, S.Kom</td>
                                    <td>Pengajar RPL</td>
                                </tr>
                                <tr>
                                    <td>ERVI RAHMAWATI, ST</td>
                                    <td>Pengajar RPL</td>
                                </tr>
                                <tr>
                                    <td>WAHYU TRI WULANSARI, S.Pd</td>
                                    <td>Pengajar RPL</td>
                                </tr>
                                <tr>
                                    <td>SAFIRA MAYA SHOVIE, S.Pd</td>
                                    <td>Pengajar RPL</td>
                                </tr>
                                <tr>
                                    <td>NOVI DYAH PUSPITASARI, S.Pd</td>
                                    <td>Pengajar RPL</td>
                                </tr>
                                <tr>
                                    <td>KHOIRUR ROZIQ, S.Pd</td>
                                    <td>Pengajar RPL</td>
                                </tr>
                                <tr>
                                    <td>FIKROTU DWI FUADATUZZAHRO</td>
                                    <td>Pengajar RPL</td>
                                </tr>
                                <tr>
                                    <td>LABIB FAYUMI</td>
                                    <td>Pengajar RPL</td>
                                </tr>
                            </tbody>
                        </div>
                    </div>
                <!-- </div>
            </div>
            <div class="row">
                <div class="col-6">
                    <h3>Blog</h3>
                    <?php foreach ($data['blog'] as $blog) : ?>
                        <u1>
                            <li><?= $blog['penulis']; ?></li>
                            <li><?= $blog['judul']; ?></li>
                            <li><?= $blog['tulisan']; ?></li>
                        </u1>
                    <?php endforeach; ?>
                </div>
            </div>
        </div> -->
    </body>
</html>