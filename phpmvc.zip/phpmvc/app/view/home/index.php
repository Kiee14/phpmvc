<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial- scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Halaman <?= $data['judul']; ?></title>
    <link rel="stylesheet" href="http://localhost/phpmvc/public/css/bootstrap.css">
</head>

<body>
    <div class="container">
        <div class="jumbotron mt-4">
            <h1>Selamat Datang di Website SMKN 2 TRENGGALEK</h1>
            <!-- <p class="lead">Perkenalkan, saya <?= $data['nama']; ?></p> -->
            <hr class="my-4">
            <div class="card" style="max-width: 1190px;">
                <div class="row no-gutters">
                    <div class="col-md-4">
                        <img src="img/gambar1.jpg" class="card-img" alt="...">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title">Sambutan Kepala SMKN 2 Trenggalek</h5>
                            <p class="card-text">Bismillahirohmannirrohim
                                Assalamualaikum Warahmatullah Wabarakatuh
                                
                                Selamat datang di website resmi SMKN 2 Trenggalek.
                                Saya berharap Website ini dapat dijadikan wahana interaksi yang positif baik antar civitas akademika maupun masyarakat pada umumnya sehingga dapat menjalin silaturahmi yang erat disegala unsur.
                                Mari kita bekerja dan berkarya dengan mengharap ridho sang Kuasa dan keikhlasan yang tulus, dijiwai demi anak bangsa.
                                
                                Terima kasih semoga Allah ‘Azza Wa Jalla menyertai doa kita semua……amin </p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- <p>It Uses utility classes for typography and spacing to space content out within the larger container.</p> -->
            <!-- <a class="btn btn-primary btn-lg" href="#" role="button">Mulai</a> -->
        </div>
    </div>
</body>

</html>