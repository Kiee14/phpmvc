<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial- scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Halaman <?= $data['judul']; ?></title>
    </head>
    <body>
        <div class="col-sm-8">
            <div class="card-body">
                <h5 class="card-title">KOMPETENSI KEAHLIAN SMK NEGERI 2 TRENGGALEK</h5>
                <div class="row">
                    <div class="col-sm-3">
                        <div class="card text-center">
                            <div class="card-body">
                                <img src="img/akl.jpg" class="img-fluid" alt="" width="100px">
                                <h5 class="card-title">AKL</h5>
                                <p class="card-text">Akuntansi dan Keuangan Lembaga (AKL) merupakan salah satu Kompetensi Keahlian dari Program Keahlian: Akuntansi dan Keuangan, dan Bidang Keahlian: Bisnis dan Manajemen. Jurusan akuntansi adalah jurusan yang banyak peluang kerja, mempelajari tentang pencatatan dan penyusunan laporan keuangan.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="card text-center">
                            <div class="card-body">
                                <img src="img/tb.jpg" class="img-fluid" alt="" width="100px">
                                <h5 class="card-title">TB</h5>
                                <p class="card-text">Tata boga merupakan salah satu disiplin ilmu pengelolaan masakan yang mempelajari teknik penyajian makanan dan minuman dengan memperhatikan estetika, kualitas rasa dan keutuhan nutrisi. Bidang ini mencakup bagaimana makanan dan minuman disiapkan menjadi sebuah hidangan regional dan nasional.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="card text-right">
                            <div class="card-body">
                                <img src="img/dpib.jpg" class="img-fluid" alt="" width="100px">
                                <h5 class="card-title">DPIB</h5>
                                <p class="card-text">Desain Pemodelan dan Informasi Bangunan adalah jurusan yang mempelajari tentang perencanaan bangunan, pelaksanaan pembuatan gedung dan perbaikan gedung.
                                    Kegiatannya adalah belajar menggambar rumah, gedung dan apartemen, menghitung biaya bangunan, melaksankan pembangunan dan memelihara kontruksi bangunan.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="card text-right">
                            <div class="card-body">
                                <img src="img/kgsp.jpeg" class="img-fluid" alt="" width="100px">
                                <h5 class="card-title">KGSP</h5>
                                <p class="card-text">Kontruksi Gedung Sanitasi dan Perawatan (KGSP) adalah sebuah Paket Keahlian baru, para peserta didik akan belajar tentang membangun sebuah bangunan, sanitasi dan kegiatan untuk merawatnya.
                                    Program belajar KGSP ini, diikuti oleh peserta didik selama 4 tahun.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="card text-right">
                            <div class="card-body">
                                <img src="img/rpl.jpg" class="img-fluid" alt="" width="100px">
                                <h5 class="card-title">RPL</h5>
                                <p class="card-text">RPL adalah sebuah jurusan yang mempelajari dan mendalami semua cara-cara pengembangan perangkat lunak termasuk pembuatan, pemeliharaan, manajemen organisasi pengembangan perangkat lunak dan manajemen kualitas.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="card text-right">
                            <div class="card-body">
                                <img src="img/tptu.jpg" class="img-fluid" alt="" width="100px">
                                <h5 class="card-title">TPTU</h5>
                                <p class="card-text">Teknik Pendigin dan Tata Udara adalah jurusan yang mempelejari tentang teknik teknik pendiginan suatu ruangan atau benda. Mahasiswa program studi ini juga mempelajari tentang aliran udara yang dapat digunakan untuk mengatur temperatur suatu ruagan atau benda. Teknik refigerasi tidak hanya digunakan untuk peralatan rumah tangga seperti kulkas, tetapi juga digunakan untuk kegiatan komersial seperti pengawetan makanan, pengaturan temperatur di gudang, rumah, gedung dan lain lain. Teknik refigerasi berhubungan langsung dengan berbagai ilmu teknik lainnya seperti fisika, mesin, listrik, kimia, industri, arsitektur dan lain lain.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>